<?php
require_once ("config.php");
require_once(ROOT_PATH . "/dwcommon.php");
require_once ("common.php");


//uploadfile
//getfile
//getcontents


?>