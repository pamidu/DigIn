app.factory('DashboardModel', function($objectstore){
  var dashboards = [];
  return {
  
  getDashboards: function(key,callback) {
    var client = $objectstore.getClient("com.duosoftware.com", "duodigin_dashboard")
    client.getByKey(key);
      client.onGetOne(function(data){
        callback(data);
      });        
    }
  }    
  
});