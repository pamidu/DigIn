# DuoProcessDesigner
Custom Workflow designer

This application is used to design the workflows which will be called by applications running on V6 platform.